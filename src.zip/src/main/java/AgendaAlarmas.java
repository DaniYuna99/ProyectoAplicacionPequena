package main.java;

import java.util.Set;

public class AgendaAlarmas {

	private Set<Alarma> alarmas;
	
	
	public AgendaAlarmas() {}
	
	
	public void addAlarma(Alarma alarma) {
		alarmas.add(alarma);
	}


	
	public Set<Alarma> getAlarmas() {
		return alarmas;
	}


	public void setAlarmas(Set<Alarma> alarmas) {
		this.alarmas = alarmas;
	}
}
