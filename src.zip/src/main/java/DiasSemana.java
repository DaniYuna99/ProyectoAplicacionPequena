package main.java;

public enum DiasSemana {
	LUNES, MARTES, MIERCOLES, JUEVES, SABADO, DOMINGO;
}
