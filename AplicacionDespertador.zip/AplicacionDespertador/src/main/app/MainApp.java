package main.app;

import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

import main.java.Alarma;
import main.java.DiasSemana;

public class MainApp {

	public static void main(String[] args) {
		
		Set<DiasSemana> dias = new HashSet<>();
		
		Alarma alarma = new Alarma(new LocalTime(20, 0, 0, 0), "colegio", "cancion.mp3", dias);
	}

}
