package main.java;

import java.time.LocalTime;
import java.util.Set;

public class Alarma {

	private LocalTime hora;
	private String nombre;
	private String tonoAlarma;
	private Set<DiasSemana> diasSemana;
	
	
	public Alarma (LocalTime hora, String tonoAlarma, Set<DiasSemana> diasSemana) {
		this.hora = hora;
		this.tonoAlarma = tonoAlarma;
		this.diasSemana = diasSemana;
	}
	
	
	public Alarma (LocalTime hora, String nombre, String tonoAlarma, Set<DiasSemana> diasSemana) {
		this.hora = hora;
		this.nombre = nombre;
		this.tonoAlarma = tonoAlarma;
		this.diasSemana = diasSemana;
	}
	
	
	
	
	public LocalTime getHora() {
		return hora;
	}


	public void setHora(LocalTime hora) {
		this.hora = hora;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getTonoAlarma() {
		return tonoAlarma;
	}


	public void setTonoAlarma(String tonoAlarma) {
		this.tonoAlarma = tonoAlarma;
	}


	public Set<DiasSemana> getDiasSemana() {
		return diasSemana;
	}


	public void setDiasSemana(Set<DiasSemana> diasSemana) {
		this.diasSemana = diasSemana;
	}

}
