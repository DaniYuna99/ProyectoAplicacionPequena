package main.java;

import java.util.Set;

public class AgendaAlarmas {

	private Set<Alarma> alarmas;
	
	
	public AgendaAlarmas() {}
	
	
	public void anadirAlarma(Alarma alarma) {
		alarmas.add(alarma);
	}
	
	public void borrarAlarma(Alarma alarma) {
		
		if(alarmas.contains(alarma)) {
			alarmas.remove(alarma);
		}
		
		/*if (!alarma.getNombre().isEmpty()) {
			if (alarmas.contains(alarma.getNombre())) {
				alarmas.remove(alarma);
			}
		
		}else {
			if(alarmas.contains(alarma.getHora()) && alarmas.contains(alarma.getDiasSemana())) {
				alarmas.remove(alarma);
			}
		}*/
		
	}
	
	
	public void modificarAlarma(Alarma alarma) {
		
	}


	
	public Set<Alarma> getAlarmas() {
		return alarmas;
	}


	public void setAlarmas(Set<Alarma> alarmas) {
		this.alarmas = alarmas;
	}
}
